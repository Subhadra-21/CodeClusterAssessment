TechStack:
-> Frontend ReactJs
    -> Material UI for page components
    -> Plotly for chart
-> Backend Nodejs
-> In memory Json files for DB

### Steps to Run application

1. unzip
2. npm install
3. Run client and serve in 2 different terminal

client:
-> npm start

server:
-> npm run server

4. localhost:3000/




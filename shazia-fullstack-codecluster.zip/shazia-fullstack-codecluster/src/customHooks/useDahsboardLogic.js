import { useState, useEffect } from "react";
import { fetchStudentScore } from "../utils/studentsAPIs";
import {toast} from "react-toastify";

const useDashboardLogic = () => {
  const [pageNum, setPageNum] = useState(1);
  const [selectedIds, setSelectedIds] = useState([]);
  const [pageCount, setPageCount] = useState(0);
  const [isLoading, setLoading] = useState(false);
  const [studentsDataMap, setStudentData] = useState({});
  const [initialized, setInitialized] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [studentCount, setStudentCount] = useState(0);

  useEffect(()=>{
    if(!initialized){
      fetchStudentData({pageNum,isInit:'init'});
      setInitialized(true);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  
  async function fetchStudentData({pageNum=1,isInit,filterText, overwrite}){
    try{
      if(studentsDataMap[pageNum] && !overwrite) return;
      setLoading(true);
      const stdata = await fetchStudentScore(pageNum-1,filterText);
      if(overwrite) setStudentData({[pageNum]:stdata?.data?.data})
      else setStudentData(st => ({...st, [pageNum]:stdata?.data?.data}));
      setPageCount(stdata?.data?.pageCount || 0);
      setStudentCount(stdata?.data?.totalStudents || 0);
      if(isInit) setSelectedIds(stdata?.data?.data?.slice(0,5));
      setLoading(false);
    }catch(err){
      toast.error("Something went wrong");
    }
  }

  function resetRowSelection(){
    setSelectedIds([]);
  }

  function handlePageChange(e, page){
    setPageNum(page);
    fetchStudentData({pageNum:page,filterText: searchText});
  }

  function handleRowSelection(r){
    setSelectedIds(selList => {
        if(selList.find(sel=>sel.id === r.id)) return selList.filter(sel => sel.id!== r.id);
        else return [...selList, r];
    })
  }

  function handleSearchChange(e){
    setSearchText(e.target.value);
  }

  function handleSearchClick(){
    setStudentData({});
    resetRowSelection();
    setPageNum(1);
    fetchStudentData({filterText: searchText, overwrite:true});
  }

  return {
    studentsdata:studentsDataMap[pageNum],
    selectedIds,
    pageNum,
    pageCount ,
    isLoading,
    searchText,
    studentCount,
    handlePageChange,
    handleRowSelection,
    resetRowSelection,
    handleSearchChange,
    handleSearchClick,
  };
};

export default useDashboardLogic;

import axios from "axios";

export async function fetchStudentScore(pageNum=0,filterText){
   let API = `/api/getStudentScores?pageNum=${pageNum}&pageLimit=10`;
   if(filterText) API += `&filterText=${filterText}`;
   const res = await axios.get(API);
   return res;
}

import Chart from "./Chart";
const DashboardPieChart = ({ chartdata }) => {

  function prepChartData() {
    const nonZeroVals = Object.keys(chartdata).reduce((prev,cur)=>{
        if(chartdata[cur]>0) prev[cur] = chartdata[cur];
        return prev;
    },{})
    const pieData = [
      {
        labels: Object.keys(nonZeroVals),
        values: Object.values(nonZeroVals),
        textinfo: "label+percent",
        hoverinfo: "none",
        insidetextorientation: "radial",
        type: "pie",
      },
    ];
    const layout = {
      width: 500,
      height: 500,
      title: "Selected Students Count(in Percent)"
    };

    return {
      data: pieData,
      layout,
    };
  }

  const plotParams = prepChartData();
  return (
     <Chart plotParams={plotParams} />
  );
};

export default DashboardPieChart;

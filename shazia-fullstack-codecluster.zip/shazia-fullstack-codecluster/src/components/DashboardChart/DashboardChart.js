import BarChart from "./BarChart";
import PieChart from "./PieChart";
import "./DashboardChart.css";

const DashboardChart = ({selectedData}) => {
    function processChartData() {
        let scoreRanges = {
          "<=200": 0,
          "201-300": 0,
          "301-400": 0,
          "401-500": 0,
          ">500": 0,
        };
        return selectedData.reduce((prev, st) => {
          const score = st.score;
          switch (true) {
            case score > 500 && score <= 600:
              prev[">500"]++;
              break;
            case score > 400 && score <= 500:
              prev["401-500"]++;
              break;
            case score > 300 && score <= 400:
              prev["301-400"]++;
              break;
            case score > 200 && score <= 300:
              prev["201-300"]++;
              break;
            default:
              prev["<=200"]++;
              break;
          }
          return prev;
        }, scoreRanges);
      }
const chartdata = processChartData();
  return (
    <div className="chartContainer">
        <BarChart chartdata={chartdata} />
        <PieChart chartdata={chartdata}/>
    </div>
  )
}

export default DashboardChart;
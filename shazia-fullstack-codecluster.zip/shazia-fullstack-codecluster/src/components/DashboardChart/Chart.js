
import Plot from "react-plotly.js";

const Chart = ({plotParams}) => {
  return (
    <Plot {...plotParams} />
  )
}

export default Chart;
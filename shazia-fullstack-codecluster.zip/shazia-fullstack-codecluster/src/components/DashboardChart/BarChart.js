import Chart from "./Chart";
const DashboardBarChart = ({ chartdata }) => {

  function prepChartData() {
    const barData = [
      {
        x: Object.keys(chartdata),
        y: Object.values(chartdata),
        text: Object.values(chartdata),
        textposition: "auto",
        hoverinfo: "none",
        marker: {
          color: "rgb(158,202,225)",
          opacity: 0.6,
          line: {
            color: "rgb(8,48,107)",
            width: 1.5,
          },
        },
        type: "bar",
      },
    ];
    const layout = {
      width: 500,
      height: 500,
      title: "Selected Students Summary",
      xaxis: {
        title: "Score Ranges",
        tickangle: -45,
      },
      yaxis: {
        title: 'No. of Students',
      }
    };

    return {
      data: barData,
      layout,
    };
  }

  const plotParams = prepChartData();
  return (
     <Chart plotParams={plotParams} />
  );
};

export default DashboardBarChart;

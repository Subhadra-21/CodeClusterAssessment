import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import Paper from "@mui/material/Paper";
import Checkbox from "@mui/material/Checkbox";
import TableTools from "./TableTools";
import { headerConfig } from "./config";
import "./index.css";

const DashboardTable = ({
  studentsdata = [],
  selectedIds = [],
  searchText,
  handleRowSelection,
  resetRowSelection,
  handleSearchChange,
  handleSearchClick,
  studentCount,
}) => {
  return (
    <>
      <TableTools
        searchText={searchText}
        resetRowSelection={resetRowSelection}
        handleSearchChange={handleSearchChange}
        handleSearchClick={handleSearchClick}
      />
      <TableContainer component={Paper} className="tableContainer">
        <Table sx={{ minWidth: 650 }} aria-label="simple table">
          <TableHead>
            <TableRow
              sx={{
                "& th": {
                  color: "#000",
                  backgroundColor: "#f3f4f5",
                  fontSize: "14px",
                  fontWeight: "600",
                },
              }}
            >
              {
                <>
                  <TableCell></TableCell>
                  {headerConfig.map((h) => (
                    <TableCell key={h.field}>{h.headerName}</TableCell>
                  ))}
                </>
              }
            </TableRow>
          </TableHead>
          <TableBody>
            {
              studentsdata.length === 0 && 
              <TableRow sx={{ "&:last-child td, &:last-child th": { border: 0 } }} className="norow">
                <TableCell colSpan={6}>
                  No Students Found
                </TableCell>
              </TableRow>
            }
            {studentsdata.length > 0 && studentsdata.map((row) => {
              const isSelected = selectedIds.find((sel) => sel.id === row.id);
              return (
                <TableRow
                  key={row.id}
                  sx={{ "&:last-child td, &:last-child th": { border: 0 } }}
                  className={isSelected ? "selRow" : ""}
                >
                  <>
                    <TableCell>
                      <Checkbox
                        checked={isSelected ? true : false}
                        onChange={() => handleRowSelection({ ...row })}
                      />
                    </TableCell>
                    {headerConfig.map((h) => (
                      <TableCell key={h.field}>{row[h.field]}</TableCell>
                    ))}
                  </>
                </TableRow>
              );
            })}

          </TableBody>
        </Table>
      </TableContainer>
      <div className="footer">
        <span>Number of selected students: {selectedIds.length}</span>
        <span>Total Students: {studentCount}</span>
      </div>
    </>
  );
};

export default DashboardTable;

export const headerConfig = [
    {field: 'id', headerName: 'ID' },
    {field: 'name', headerName: 'Student Name' },
    {field: 'grade', headerName: 'Grade' },
    {field: 'score', headerName: 'Score' },
    {field: 'percentage', headerName: 'Percentage' }
];



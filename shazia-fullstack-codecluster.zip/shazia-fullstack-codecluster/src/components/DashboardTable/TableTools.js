import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import SearchIcon from "@mui/icons-material/Search";
import InputAdornment from "@mui/material/InputAdornment";

const TableTools = ({
  searchText,
  handleSearchChange,
  handleSearchClick,
  resetRowSelection,
}) => {
  return (
    <div className="tableTools">
      <TextField
        variant="outlined"
        label="Search Name, Grade"
        value={searchText}
        onChange={handleSearchChange}
        InputProps={{
          endAdornment: (
            <InputAdornment position="end">
              <Button
                variant="contained"
                color="primary"
                onClick={handleSearchClick}
              >
                <SearchIcon />
              </Button>
            </InputAdornment>
          ),
        }}
      />
      <Button
        variant="contained"
        color="primary"
        onClick={resetRowSelection}
        className="resetBtn"
      >
        Reset Students Selection
      </Button>
    </div>
  );
};

export default TableTools;

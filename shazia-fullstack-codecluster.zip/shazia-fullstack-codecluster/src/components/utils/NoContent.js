import "./NoContent.css";
const NoContent = ({text}) => {
  return (
    <div className="noContent">{text}</div>
  )
}

export default NoContent;
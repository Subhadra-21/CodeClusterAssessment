// import ReactPaginate from "react-paginate";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import "./Pagination.css";

const PaginationComp = ({ handlePageClick, pageCount, pageNum }) => {
  return (
    <div className="paginationContainer">
      {pageCount > 1 ? (
        <Stack spacing={2}>
          <Pagination
            count={pageCount}
            page={pageNum}
            onChange={handlePageClick}
            color="primary"
            size="large"
          />
        </Stack>
      ) : null}
    </div>
  );
};

export default PaginationComp;

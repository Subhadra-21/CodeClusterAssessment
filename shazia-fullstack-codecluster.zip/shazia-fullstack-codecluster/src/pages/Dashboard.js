import DashboardTable from "../components/DashboardTable";
import useDashboardLogic from "../customHooks/useDahsboardLogic";
import Pagination from "../components/utils/Pagination";
import NoContent from "../components/utils/NoContent";
import DashboardChart from "../components/DashboardChart/DashboardChart";
import "./index.css";

const Dashboard = () => {
  const {
    studentsdata,
    isLoading,
    selectedIds,
    pageNum,
    pageCount,
    searchText,
    studentCount,
    handlePageChange,
    handleRowSelection,
    resetRowSelection,
    handleSearchChange,
    handleSearchClick,
  } = useDashboardLogic();

  if (isLoading) return <NoContent text="Loading..." />;

  return (
    <div className="dbPage">
     
        <DashboardChart
        selectedData={selectedIds} 
        />
      
      

      <DashboardTable
        studentsdata={studentsdata}
        selectedIds={selectedIds}
        handleRowSelection={handleRowSelection}
        resetRowSelection={resetRowSelection}
        handleSearchChange={handleSearchChange}
        handleSearchClick={handleSearchClick}
        searchText={searchText}
        studentCount={studentCount}
      />
      <Pagination
        handlePageClick={handlePageChange}
        pageNum={pageNum}
        pageCount={pageCount}
      />
    </div>
  );
};

export default Dashboard;

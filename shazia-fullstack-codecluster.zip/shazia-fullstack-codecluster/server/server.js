const express = require("express");
const app = express();

app.use("/", require("./routes/studentScore.routes"));

app.listen(4000, ()=>{
    console.log("server running at 4000");
})
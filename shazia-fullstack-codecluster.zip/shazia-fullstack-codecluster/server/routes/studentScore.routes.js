const express = require("express");
const router = express.Router();

const getStudentScoresController = require("../controllers/getStudentScores.controller.js");

router.get("/api/getStudentScores", getStudentScoresController);

module.exports = router;
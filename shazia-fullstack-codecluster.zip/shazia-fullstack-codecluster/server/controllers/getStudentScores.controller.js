const scoreJsonDB = require("../db/studentsScore.json");

function checkContains(data, text){
 return data.toLowerCase().indexOf(text) > -1;
}

function getStudentScores(req, res, next) {
  try {
    let { pageNum = 0, pageLimit = 10, filterText="" } = req.query;
    pageLimit=parseInt(pageLimit);
    filterText = filterText.toLowerCase();
    const startIndex = pageLimit * pageNum;
    const endIndex = startIndex + pageLimit;
    // console.log(pageNum, pageLimit,startIndex,endIndex);
    let scoreJson = scoreJsonDB;
    if(filterText){
      scoreJson = scoreJson.filter(st => checkContains(st.name, filterText) || checkContains(st.grade, filterText))
    }
    const extractData = scoreJson.slice(startIndex, endIndex);
    const pageCount = Math.ceil(scoreJson.length / pageLimit);
    res.status(200).send({ data: extractData, pageCount, totalStudents: scoreJson.length });
  } catch (err) {
    next("failed to get students scores")
  }
}

module.exports = getStudentScores;